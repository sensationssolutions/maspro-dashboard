export const environment = {

  
  // apiUrl: 'https://api.stadshaven.com/public/api',
  // frontendUrl: 'https://dashboard.stadshaven.com',
  // assetsUrl: 'https://api.stadshaven.com/public/',

  apiUrl: 'http://127.0.0.1:8000/api',
  frontendUrl: 'http://localhost:55484',
  assetsUrl: 'http://127.0.0.1:8000/',
  
};

