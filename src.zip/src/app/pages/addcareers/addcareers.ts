import { Component } from '@angular/core';

@Component({
  selector: 'app-addcareers',
  imports: [],
  templateUrl: './addcareers.html',
  styleUrl: './addcareers.css'
})
export class Addcareers {

}
