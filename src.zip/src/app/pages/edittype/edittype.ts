import { Component } from '@angular/core';

@Component({
  selector: 'app-edittype',
  templateUrl: './edittype.html',
  styleUrls: ['./edittype.css']
})
export class Edittype {
  // TODO: Implement logic to edit an existing type
} 